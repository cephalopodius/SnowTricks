

-Create database nammed "snowtricks"
-import the database with the sql file (there is json column so check if you have a advanced enough version to read it)
-